import { Routes } from '@angular/router';

import { Home } from './home/home';
import { Login } from './login/login';
import { Profile } from './profile/profile';
import { Register } from './register/register';
import { Contact } from './contact/contact';
import { About } from './about/about';
import { Harshitha } from './harshitha/harshitha';
export const routes: Routes = [
  { path: '', component: Home },
  { path: 'home', component: Home },
  { path: 'about', component: About },
  { path: 'contact', component: Contact },
  { path: 'profile', component: Profile},
  { path: 'login', component: Login },
  { path: 'register', component: Register },
  { path :'harshitha',component : Harshitha }
];