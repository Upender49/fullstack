import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
@Component({
  selector: 'app-harshitha',
  imports: [RouterModule],
  templateUrl: './harshitha.html',
  styleUrl: './harshitha.css',
})
export class Harshitha {}
