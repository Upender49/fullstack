import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Harshitha } from './harshitha';

describe('Harshitha', () => {
  let component: Harshitha;
  let fixture: ComponentFixture<Harshitha>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Harshitha],
    }).compileComponents();

    fixture = TestBed.createComponent(Harshitha);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
