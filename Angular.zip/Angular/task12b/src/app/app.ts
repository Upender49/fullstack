import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import {FormsModule} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { User } from './user';
@Component({
  selector: 'app-root',
  imports: [FormsModule,CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('task12b');

  users: any[] = [];

  name = '';
  email = '';
  phone = '';

  constructor(private service: User) {}

  loadUsers() {
    this.users = this.service.getUsers();
  }

  addUser() {
    this.service.addUser({
      name: this.name,
      email: this.email,
      phone: this.phone
    });

    this.loadUsers();

    this.name = '';
    this.email = '';
    this.phone = '';
  }

  deleteUser(i: number) {
    this.service.deleteUser(i);
    this.loadUsers();
  }
}
