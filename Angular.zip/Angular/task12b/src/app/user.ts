import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class User {
  users: any[] = [];

  getUsers() {
    return this.users;
  }

  addUser(user: any) {
    this.users.push(user);
  }

  deleteUser(index: number) {
    this.users.splice(index, 1);
  }
}
