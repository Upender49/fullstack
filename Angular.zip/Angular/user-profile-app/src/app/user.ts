import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
@Injectable({
  providedIn: 'root',
})
export class User {
//   API = "http://localhost:3000/users";
// 
//   constructor(private http: HttpClient) {}
// 
//   getUsers() {
//     return this.http.get(this.API);
//   }
// 
//   addUser(user: any) {
//     return this.http.post(this.API, user);
//   }
// 
//   updateUser(id: string, user: any) {
//     return this.http.put(`${this.API}/${id}`, user);
//   }
// 
//   deleteUser(id: string) {
//     return this.http.delete(`${this.API}/${id}`);
//   }
}
