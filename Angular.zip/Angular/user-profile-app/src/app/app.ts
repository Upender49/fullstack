import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './app.html'
})
export class App {

  users: any[] = [];

  user = { name: '', email: '', phone: '' };

  editIndex: number | null = null;

  // ➕ CREATE
  addUser() {
    if (this.editIndex === null) {
      this.users.push({ ...this.user }); // add new
    } else {
      this.users[this.editIndex] = { ...this.user }; // update
      this.editIndex = null;
    }

    this.user = { name: '', email: '', phone: '' };
  }

  // 📝 EDIT
  editUser(index: number) {
    this.user = { ...this.users[index] };
    this.editIndex = index;
  }

  // ❌ DELETE
  deleteUser(index: number) {
    this.users.splice(index, 1);
  }
}